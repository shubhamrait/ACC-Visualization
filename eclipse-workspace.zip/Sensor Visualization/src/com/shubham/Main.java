package com.shubham;

import java.io.*;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVFormat;
import javax.swing.*;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.net.Socket;
import java.util.concurrent.TimeUnit;

import com.jujutsu.tsne.TSneConfiguration;
import com.jujutsu.tsne.MemOptimizedTSne;
import com.jujutsu.tsne.PrincipalComponentAnalysis;
//import com.jujutsu.tsne.FastTSne;
import com.jujutsu.utils.TSneUtils;

/*class Main 
{
	public static void main(String args[])
	{
			int initial_dims = 3;
		    double perplexity = 4.0;
		    double [][] X = {{3,6,4},{9,1,5},{81,23,48},{323,393,832},{60,89,99}};
		    System.out.println(MatrixOps.doubleArrayToPrintString(X, ", "));
		    BarnesHutTSne tsne;
		    boolean parallel = false;
			if(parallel) {			
				tsne = new ParallelBHTsne();
			} else {
				tsne = new BHTSne();
			}
		        TSneConfiguration config = TSneUtils.buildConfig(X, 2, initial_dims, perplexity, 1000);
			double [][] Y = tsne.tsne(config); 
			System.out.println(MatrixOps.doubleArrayToPrintString(Y, ", "));
	}
}*/

class ClientThread2
{
	static boolean running = true;
	static String message = "Alright";
	static String macaddr = "7c:46:85:80:77:08";
}

class MainThread implements Runnable
{
	String ipaddr;
	int port;

	public MainThread(String a, int b)
	{
		this.ipaddr = a;
		this.port = b;
	}

	public void run()
	{
		Socket sock = null;
		try
		{
			sock = new Socket(this.ipaddr, this.port);
			Thread thread = new Thread(new SendThread(sock));
			thread.start();
			Thread thread2 = new Thread(new RecieveThread(sock));
			thread2.start();
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(Main.f, "ERROR!!______________ main thread\n" + e.getMessage());
			Main.running = false;

			// System.exit(0);
		}

	}
}

class RecieveThread implements Runnable
{
	Socket sock = null;
	BufferedReader recieve = null;

	public RecieveThread(Socket sock) // constructor to initialise the values
	{
		this.sock = sock;
	}

	public void run()
	{
		try
		{
			recieve = new BufferedReader(new InputStreamReader(this.sock.getInputStream()));// get inputstream
			String msgRecieved = "Hello";
			while (Main.running == true)
			{
				msgRecieved = recieve.readLine();
				if (msgRecieved.equals(null))
				{
					break;
				}
				Main.message = msgRecieved;
			}
			if (Main.running == false)
			{
				JOptionPane.showMessageDialog(Main.f, "Exit from Receive Thread \n");
			}
		} catch (NullPointerException ex)
		{
			JOptionPane.showMessageDialog(Main.f, "ERROR!!______________ receive thread\n" + ex.getMessage());
			Main.running = false;

		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(Main.f, "ERROR!!______________ receive thread\n" + e.getMessage());
			Main.running = false;

			// System.exit(0);
		}
	}// end run
}// end class recievethread

class SendThread implements Runnable
{
	Socket sock = null;
	PrintWriter print = null;
	BufferedReader brinput = null;

	public SendThread(Socket sock)
	{
		this.sock = sock;
	}// end constructor

	public void run()
	{
		try
		{
			if (sock.isConnected())
			{
				// System.out.println("Client connected to "+sock.getInetAddress() + " on port
				// "+sock.getPort());
				this.print = new PrintWriter(sock.getOutputStream(), true);
				while (Main.running == true)
				{

					this.print.println(ClientThread2.message);
					this.print.flush();

				} // end while
					// sock.close();
				if (Main.running == false)
				{
					System.out.println("Exit from Send Thread \n");
				}
			}
		} catch (Exception e)
		{
			JOptionPane.showMessageDialog(Main.f, "ERROR!!______________ send thread\n" + e.getMessage());
			Main.running = false;

			// System.exit(0);
		}
	}// end run method
}// end class

public class Main
{
	static String message = "00,00,00";
	static boolean running = true;
	static String macaddr = "7c:46:85:80:77:08";
	static JFrame f;
	static double A=0, temp=0;
	static int flag;
	static int mode = 0;
	static double T=0;
	static long time =0,previous=0,current=0;

	public static void main(String[] args) throws Exception
	{
		int i, j, port = 6000;
		double tsneinput[][] = new double[20000][3];
		double ax=9, ay=9, az=9;
		String ipaddr = "192.168.137.122";
		f = new JFrame("Accelerometer sensor");// creating instance of JFrame
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel l = new JLabel();
		l.setText("Hello1");
		JLabel l1 = new JLabel();
		l1.setText("Hello2");
		JLabel l2 = new JLabel();
		l2.setText("Hello3");
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		f.setSize(screenSize.width / 2, screenSize.height / 2);// 400 width and 500 height
		l.setBounds(0, 0, screenSize.width / 2, screenSize.height / 20);
		l1.setBounds(0, screenSize.height / 20, screenSize.width / 2, screenSize.height / 20);
		l2.setBounds(0, screenSize.height / 10, screenSize.width / 2, screenSize.height / 20);

		f.setLayout(null);// using no layout managers
		f.setVisible(true);// making the frame visible
		l.setText("123 123");
		f.add(l);
		// f.add(l1);
		f.add(l2);
		l.setText("123 456");
		l1.setVisible(true);
		l1.setText("Hey there");
		f.add(l1);
		//ipaddr = JOptionPane.showInputDialog(f, "Enter IP address");
		try
		{
			Main.mode = Integer.parseInt(ipaddr);
		} catch (Exception e)
		{
			Main.mode = 0;
		}
		// ipaddr=new Scanner(System.in).nextLine();
		Thread th = new Thread(new MainThread(ipaddr, port));
		l2.setText("Client connected to " + ipaddr + " on port " + port);
		th.start();
		int counter = 0;
		Main.time = 0;
		current = System.nanoTime();
		double ux=0.0,uy=0.0,uz=0.0;
		/*use log for debugging*///double log[][]=new double[20000][7];
		while(true)
		{
			previous=current;
			TimeUnit.NANOSECONDS.sleep(10);
			if (Main.running == false)
			{
				{
					Main.running = true;
					l1.setText("Trying to connect....");
					th = new Thread(new MainThread(ipaddr, port));
					th.start();
				}
			}
			i = 0;
			String a[] = Main.message.split(",");
			ax = Double.parseDouble(a[0]);
			ay = Double.parseDouble(a[1]);
			az = Double.parseDouble(a[2]);
			current=System.nanoTime();
			Main.time = current-previous;
			l.setText(a[0] + " " + a[1] + " " + a[2] + "   " + "A: " + A);
			if(ax == 999.0 || ay == 999.0 || az == 999.0)
			{
				if(mode==1)
				{
					mode=2;
				}
			}
			if ((ax != 555.0 || ay != 555.0 || az != 555.0)&&(ax != 999.0 || ay != 999.0 || az != 999.0))
			{
				if(mode==0)
				{
					mode=1;
				}
				A = Math.sqrt(ax * ax + ay * ay + az * az);
				if ((Main.temp < Main.A) && flag == 0)
				{
					Main.temp = Main.A;
				}
				T = (Main.time)*(1e-9);
				if (Main.mode==1)
				{
					tsneinput[counter][0] = (ux*T + ax * T * T/2);
					tsneinput[counter][1] = (uy*T + ay * T * T/2);
					tsneinput[counter][2] = (uz*T + az * T * T/2);
					//log[counter][0]=ax;
					//log[counter][1]=ay;
					//log[counter][2]=az;
					//log[counter][3]=ux;
					//log[counter][4]=uy;
					//log[counter][5]=uz;
					//log[counter][6]=T;
					ux=ux+ax*T;
					uy=uy+ay*T;
					uz=uz+az*T;
					//{
						//System.out.println("fuck you");
						//System.out.println(tsneinput[i][0]+"  "+tsneinput[i][1]+"  "+tsneinput[i][2]+"  "+log[i][0]+"  "+log[i][1]+"  "+log[i][2]+"  "+log[i][3]+"  "+(log[i][4])+"  "+log[i][5]+"  "+log[i][6]);
					//}
				}
				counter++;
			} 
			else if (Main.mode==2)
			{
				break;
			}
		}
		System.out.println("Broke free");
		double INPUT[][] = new double[counter + 1][3];
		for (i = 0; i <= counter; i++)
		{
			for (j = 0; j <= 2; j++)
			{
				INPUT[i][j] = tsneinput[i][j];
			}
		}
		try (CSVPrinter printer = new CSVPrinter(new FileWriter("INPUT.csv"), CSVFormat.EXCEL))
		{
			printer.printRecord("INPUT[i][0]","INPUT[i][1]","INPUT[i][2]","log[i][0]","log[i][1]","log[i][2]","log[i][3]","log[i][4]","log[i][5]","log[i][6]");
			
			for(i=0;i<=counter;i++)
			{
				printer.printRecord(INPUT[i][0],INPUT[i][1],INPUT[i][2]/*,log[i][0],log[i][1],log[i][2],log[i][3],log[i][4],log[i][5],log[i][6]*/);
			}
		} 
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		for(i=0;i<=counter;i++)
		{
			System.out.println(INPUT[i][0]+"  "+INPUT[i][1]+"  "+INPUT[i][2]/*+"  "+log[i][0]+"  "+log[i][1]+"  "+log[i][2]+"  "+log[i][3]+"  "+(log[i][4])+"  "+log[i][5]+"  "+log[i][6]*/);
		}
		int initial_dims = 3;
		double perplexity = 70.0;
		MemOptimizedTSne tsne = new MemOptimizedTSne();
		TSneConfiguration config = TSneUtils.buildConfig(INPUT, 2, initial_dims, perplexity, 4000);
		tsneinput=null;
		System.gc();
		double[][] Y = tsne.tsne(config);
		System.gc();
		try (CSVPrinter printer = new CSVPrinter(new FileWriter("TSNEreduced.csv"), CSVFormat.EXCEL))
		{
			for(i=0;i<=counter;i++)
			{
				printer.printRecord(Y[i][0],Y[i][1]);
			}
		} 
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		System.gc();
		System.out.println("TSNE Over");
		PrincipalComponentAnalysis ppp = new PrincipalComponentAnalysis();
		Y = ppp.pca(INPUT, 2);
		System.gc();
		try (CSVPrinter printer = new CSVPrinter(new FileWriter("PCAreduced.csv"), CSVFormat.EXCEL))
		{
			for(i=0;i<=counter;i++)
			{
				printer.printRecord(Y[i][0],Y[i][1]);
			}
		} 
		catch (IOException ex)
		{
			ex.printStackTrace();
		}
		System.out.println("PCA Over");
	}
}
