package com.jujutsu.tsne.barneshut;

public interface Distance {
	double distance(DataPoint d1, DataPoint d2);
}
