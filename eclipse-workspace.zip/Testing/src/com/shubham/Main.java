package com.shubham;

import java.util.concurrent.TimeUnit;
public class Main
{ 
	static double time=0;
	public static void main(String[] args)
	{
		Main.time = System.nanoTime();
		try
		{
			TimeUnit.SECONDS.sleep(2);
		} catch (InterruptedException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Main.time = System.nanoTime() - Main.time;
		System.out.println(Math.pow(10, -9)*Main.time);
	}

}
