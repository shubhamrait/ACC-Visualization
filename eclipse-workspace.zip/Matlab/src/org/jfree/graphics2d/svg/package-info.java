/**
 * Contains {@link org.jfree.graphics2d.svg.SVGGraphics2D} and supporting 
 * classes that allow Java2D rendering to Scalable Vector Graphics (SVG) format.
 */
package org.jfree.graphics2d.svg;