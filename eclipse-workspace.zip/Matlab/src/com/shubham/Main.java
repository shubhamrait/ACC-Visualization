package com.shubham;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.awt.Toolkit;
import com.shubham.MatrixUtils;

public class Main
{
	private Frame mainFrame;

	public Main()
	{
		prepareGUI();
	}

	public static void main(String[] args) throws Exception
	{
		Main awtControlDemo = new Main();
		awtControlDemo.showCanvasDemo("C:/Users/Shubahm/eclipse-workspace/Sensor Visualization/TSNEreduced.csv");
		Main awtControlDemo1 = new Main();
		awtControlDemo1.showCanvasDemo("C:/Users/Shubahm/eclipse-workspace/Sensor Visualization/PCAreduced.csv");
	
	}

	private void prepareGUI()
	{
		mainFrame = new Frame("Displacement visualization in 2D");
		mainFrame.setSize(Toolkit.getDefaultToolkit().getScreenSize().width,
				Toolkit.getDefaultToolkit().getScreenSize().height);
		mainFrame.setLayout(new GridLayout(1, 1));
		mainFrame.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent windowEvent)
			{
				System.exit(0);
			}
		});
		
	}

	private void showCanvasDemo(String s)
	{
		mainFrame.add(new MyCanvas(s));
		mainFrame.setVisible(true);
	}

}

class MyCanvas extends Canvas
{
	private static final long serialVersionUID = 1L;
	static Button b, b2;
	static Graphics g;
	public String location="";
	public MyCanvas()
	{
		setBackground(Color.WHITE);
		setSize(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height);
	}//C:/Users/Shubahm/eclipse-workspace/Sensor Visualization/TSNEreduced.csv
	public MyCanvas(String s)
	{
		this.location=s;
		setBackground(Color.WHITE);
		setSize(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height);
	
	}
	public void paint(Graphics g)
	{
		// g.drawString ("It is a custom canvas area", 70, 70);
		MyCanvas.g = g;
		b = new Button();
		b.setBounds(Toolkit.getDefaultToolkit().getScreenSize().width - 100, 0, 100, 100);
		b.setLabel("+");
		b2 = new Button();
		b2.setBounds(Toolkit.getDefaultToolkit().getScreenSize().width - 100, 120, 100, 100);
		b.setLabel("-");
		double[][] X = MatrixUtils.simpleRead2DMatrix(new File(this.location), ",");
		System.out.println("Width: " + Toolkit.getDefaultToolkit().getScreenSize().width);
		System.out.println("Height: " + Toolkit.getDefaultToolkit().getScreenSize().height);
		System.out.println(X.length);
		System.out.println(X[0].length);
		double maxx = X[0][0], minx = X[0][0];
		double maxy = X[0][1], miny = X[0][1];
		double scalex, scaley, scale = 0.05;
		int margin = 50;
		for (int i = 1; i < X.length; i++)
		{
			for (int j = 0; j < X[0].length; j++)
			{
				X[i][j] = X[i][j] + X[i - 1][j];
			}
		}
		System.out.println("X length is " + X.length);
		System.out.println("X[0] length is " + X[0].length);
		for (int i = 0; i < X.length; i++)
		{

			if (X[i][0] < minx)
			{
				minx = X[i][0];
			}
			if (X[i][1] < miny)
			{
				miny = X[i][1];
			}
		}
		for (int i = 0; i < X.length; i++)
		{
			X[i][0] = X[i][0] - minx;
			X[i][1] = X[i][1] - miny;
		}
		for (int i = 0; i < X.length; i++)
		{
			if (X[i][1] > maxy)
			{
				maxy = X[i][1];
			}
			if (X[i][0] > maxx)
			{
				maxx = X[i][0];
			}
		}
		scalex = (Toolkit.getDefaultToolkit().getScreenSize().width - 2 * margin) / maxx;
		scaley = (Toolkit.getDefaultToolkit().getScreenSize().height - 2 * margin) / maxy;
		System.out.println("maxx" + maxx);
		System.out.println("maxy" + maxy);
		System.out.println("minx" + minx);
		System.out.println("miny" + miny);
		System.out.println("Scale is" + scalex + "    " + scaley);
		System.out.println("Screen size is " + (scalex * maxx) + "    " + (scaley * maxy));
		if (scalex > scaley)
		{
			scale = scaley;
		} else
		{
			scale = scalex;
		}
		//scale=scale*1.6;
		System.out.println(scale);
		for (int i = 0; i < X.length; i++)
		{
			for (int j = 0; j < X[0].length; j++)
			{
				X[i][j] = (X[i][j] * scale) + margin;
			}
		}
		for (int i = 1; i < X.length; i++)
		{
			g.drawLine((int) X[i][1], (int) X[i][0], (int) X[i - 1][1], (int) X[i - 1][0]);
		}
		 //g.drawLine(margin, margin, (int)X[0][1],(int)X[0][0]);
	}
}
