package com.example.shubahm.myapplication;

public class Configure
{
    static MainActivity main;
}
